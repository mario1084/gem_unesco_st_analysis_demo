#' Completion rate estimator
#'
#' Implements completion rate estimation according to UIS/VIEW methodology:
#' Share of reference-age group that has completed a target level.
#' Produces indicators per year per country.
#'
#' @param harmonized_data A data.table containing harmonized person-level data
#' @param level Character vector specifying education levels to estimate.
#'   Options: "primary", "lower_secondary", "upper_secondary", "tertiary"
#' @param group_vars Character vector of grouping variables (default: 
#'   c("country_code", "source_program", "survey_year", "wave_id"))
#' @param include_se Logical indicating whether to include standard errors
#'
#' @return A data.table with completion rate estimates per year per country
#' @export
estimate_completion <- function(harmonized_data,
                                level = c("primary", "lower_secondary", "upper_secondary"),
                                group_vars = c("country_code", "source_program", "survey_year", "wave_id"),
                                include_se = FALSE) {
  
  # Load utility functions
  source_path <- file.path(dirname(dirname(getwd())), "indicators", "utils", "weighted_rate.R")
  if (file.exists(source_path)) {
    source(source_path)
  }
  
  # Ensure data.table
  if (!data.table::is.data.table(harmonized_data)) {
    harmonized_data <- data.table::as.data.table(harmonized_data)
  }
  
  # Check required variables
  required_vars <- c("age_h", "highest_level_completed_h", "highest_grade_completed_h", 
                     "weight_h", "country_code", "source_program", "survey_year", "wave_id")
  missing_vars <- setdiff(required_vars, names(harmonized_data))
  if (length(missing_vars) > 0) {
    stop("Missing required variables: ", paste(missing_vars, collapse = ", "))
  }
  
  # Verify we have year and country grouping
  if (!all(c("country_code", "survey_year") %in% group_vars)) {
    warning("Grouping variables should include 'country_code' and 'survey_year' for per-year per-country estimates")
  }
  
  # Define level-specific reference age groups (based on UIS definitions)
  # These are the age groups that should have completed each level
  reference_age_groups <- list(
    primary = c(15, 24),           # Ages 15-24 should have completed primary
    lower_secondary = c(20, 29),   # Ages 20-29 should have completed lower secondary
    upper_secondary = c(25, 34),   # Ages 25-34 should have completed upper secondary
    tertiary = c(30, 39)           # Ages 30-39 should have completed tertiary
  )
  
  # Define level codes in harmonized data
  level_codes <- list(
    primary = 1,
    lower_secondary = 2,
    upper_secondary = 3,
    tertiary = 4
  )
  
  results_list <- list()
  
  for (lvl in level) {
    if (!lvl %in% names(reference_age_groups)) {
      warning("Unknown level: ", lvl, ". Skipping.")
      next
    }
    
    age_range <- reference_age_groups[[lvl]]
    level_code <- level_codes[[lvl]]
    
    # Define eligible universe: age in reference age group
    eligible_condition <- function(dt) {
      return(dt$age_h >= age_range[1] & dt$age_h <= age_range[2])
    }
    
    # Define indicator condition: has completed the target level
    indicator_condition <- function(dt) {
      # Check if highest_level_completed_h is at or above target level
      level_completed <- dt$highest_level_completed_h >= level_code
      
      # For some levels, we might also need to check grade completion
      # This is level-specific and may require additional logic
      return(level_completed)
    }
    
    # Compute completion rate
    if (include_se) {
      completion_rates <- weighted_rate_with_se(
        data = harmonized_data,
        eligible_condition = eligible_condition,
        indicator_condition = indicator_condition,
        weight_var = "weight_h",
        group_vars = group_vars,
        se_method = "binomial"
      )
    } else {
      completion_rates <- weighted_rate(
        data = harmonized_data,
        eligible_condition = eligible_condition,
        indicator_condition = indicator_condition,
        weight_var = "weight_h",
        group_vars = group_vars,
        include_counts = TRUE
      )
    }
    
    # Add level information
    completion_rates[, level := lvl]
    completion_rates[, indicator_id := "COMP_LVL"]
    completion_rates[, indicator_name := "Completion rate"]
    completion_rates[, indicator_family := "household_core"]
    
    results_list[[lvl]] <- completion_rates
  }
  
  # Combine all levels
  if (length(results_list) == 0) {
    return(data.table())
  }
  
  results <- data.table::rbindlist(results_list, fill = TRUE)
  
  # Ensure we have per-year per-country structure
  unique_combos <- unique(results[, .(country_code, survey_year, level)])
  message("Generated ", nrow(unique_combos), " unique country-year-level completion rate combinations")
  
  # Reorder columns
  base_cols <- c("country_code", "source_program", "survey_year", "wave_id", 
                 "level", "indicator_id", "indicator_name", "indicator_family",
                 "rate")
  
  if (include_se) {
    base_cols <- c(base_cols, "se", "ci_lower", "ci_upper")
  }
  
  if ("numerator" %in% names(results)) {
    base_cols <- c(base_cols, "numerator", "denominator", "n_eligible", "n_indicator")
  }
  
  # Ensure all columns exist
  existing_cols <- intersect(base_cols, names(results))
  other_cols <- setdiff(names(results), existing_cols)
  
  results <- results[, c(existing_cols, other_cols), with = FALSE]
  
  return(results)
}

#' Estimate completion rates with country-specific adjustments
#'
#' Applies country-specific rules for completion estimation based on methodology document
#' Produces indicators per year per country.
#'
#' @param harmonized_data A data.table containing harmonized person-level data
#' @param country_codes Character vector of country codes to process (default: all)
#' @param years Numeric vector of years to process (default: all)
#' @param ... Additional arguments passed to estimate_completion
#'
#' @return A data.table with completion rate estimates per year per country
#' @export
estimate_completion_country_specific <- function(harmonized_data,
                                                 country_codes = NULL,
                                                 years = NULL,
                                                 ...) {
  
  if (!data.table::is.data.table(harmonized_data)) {
    harmonized_data <- data.table::as.data.table(harmonized_data)
  }
  
  # Filter by country if specified
  if (!is.null(country_codes)) {
    harmonized_data <- harmonized_data[country_code %in% country_codes]
  }
  
  # Filter by year if specified
  if (!is.null(years)) {
    harmonized_data <- harmonized_data[survey_year %in% years]
  }
  
  # Get unique countries and years for reporting
  unique_countries <- unique(harmonized_data$country_code)
  unique_years <- unique(harmonized_data$survey_year)
  
  message("Processing completion rates for ", length(unique_countries), " countries: ", 
          paste(unique_countries, collapse = ", "))
  message("Processing years: ", paste(sort(unique_years), collapse = ", "))
  
  results_list <- list()
  
  # Process each country separately to apply country-specific rules
  for (country in unique_countries) {
    country_data <- harmonized_data[country_code == country]
    
    # Apply country-specific rules based on methodology document
    
    if (country == "ARG") {
      # Argentina: completion requires harmonized highest_level_completed_h logic
      # built from NIVEL_ED and state variables
      message("Argentina: Completion from NIVEL_ED and state variables")
      warning("Argentina completion: No completion estimate publishable until ",
              "level-status rule is stable across all waves")
      
      country_results <- estimate_completion(country_data, ...)
      
    } else if (country == "HND") {
      # Honduras: ED05 + ED08 provide direct highest-level/highest-grade block
      message("Honduras: Completion from ED05 + ED08")
      country_results <- estimate_completion(country_data, ...)
      
    } else if (country == "PRY") {
      # Paraguay: ED0504 must be split first in harmonization layer
      message("Paraguay: Completion from ED0504 (requires split in harmonization)")
      country_results <- estimate_completion(country_data, ...)
      
    } else {
      # Default for other countries
      message(country, ": Using standard completion estimation")
      country_results <- estimate_completion(country_data, ...)
    }
    
    # Add country-specific metadata
    if (nrow(country_results) > 0) {
      country_results[, country_specific_notes := get_country_completion_notes(country)]
      results_list[[country]] <- country_results
    }
  }
  
  # Combine results
  if (length(results_list) == 0) {
    return(data.table())
  }
  
  results <- data.table::rbindlist(results_list, fill = TRUE)
  
  # Verify per-year per-country structure
  summary_stats <- results[, .(
    n_estimates = .N,
    min_year = min(survey_year, na.rm = TRUE),
    max_year = max(survey_year, na.rm = TRUE)
  ), by = country_code]
  
  message("\nSummary of completion estimates:")
  for (i in 1:nrow(summary_stats)) {
    message("  ", summary_stats$country_code[i], ": ", 
            summary_stats$n_estimates[i], " estimates (", 
            summary_stats$min_year[i], "-", summary_stats$max_year[i], ")")
  }
  
  return(results)
}

#' Get country-specific completion estimation notes
#'
#' @param country_code Character country code
#'
#' @return Character string with country-specific notes
#' @export
get_country_completion_notes <- function(country_code) {
  notes <- list(
    ARG = "Completion from NIVEL_ED and state variables; publishability depends on wave stability",
    HND = "Completion from ED05 + ED08 direct highest-level/highest-grade block",
    PRY = "Completion from ED0504 (requires split in harmonization layer)"
  )
  
  return(notes[[country_code]] %||% "Standard completion estimation")
}

#' Estimate completion rates for all available levels and countries
#'
#' Main function for completion rate estimation pipeline.
#' Produces CSV output with per-year per-country indicators.
#'
#' @param harmonized_data_path Path to harmonized data file (Parquet or CSV)
#' @param output_path Path to write output CSV (required)
#' @param years Numeric vector of years to process (default: all available)
#' @param countries Character vector of country codes to process (default: all available)
#' @param levels Character vector of education levels to estimate
#' @param include_se Logical indicating whether to include standard errors
#'
#' @return A data.table with completion rate estimates per year per country
#' @export
run_completion_estimation <- function(harmonized_data = NULL,
                                      harmonized_data_path = NULL,
                                      output_path = NULL,
                                      years = NULL,
                                      countries = NULL,
                                      levels = c("primary", "lower_secondary", "upper_secondary"),
                                      group_vars = c("country_code", "source_program", "survey_year", "wave_id"),
                                      include_se = FALSE) {
  
  # Load harmonized data if not provided directly
  if (is.null(harmonized_data)) {
    if (!is.null(harmonized_data_path)) {
      message("Loading harmonized data from: ", harmonized_data_path)
      if (grepl("\\.parquet$", harmonized_data_path, ignore.case = TRUE)) {
        if (!requireNamespace("arrow", quietly = TRUE)) {
          stop("Package 'arrow' required for Parquet files")
        }
        harmonized_data <- arrow::read_parquet(harmonized_data_path)
      } else if (grepl("\\.csv$", harmonized_data_path, ignore.case = TRUE)) {
        harmonized_data <- data.table::fread(harmonized_data_path)
      } else if (grepl("\\.csv\\.gz$", harmonized_data_path, ignore.case = TRUE)) {
        harmonized_data <- data.table::fread(harmonized_data_path)
      } else {
        stop("Unsupported file format. Use .parquet, .csv, or .csv.gz")
      }
    } else {
      stop("Either harmonized_data or harmonized_data_path is required")
    }
  }
  
  # Convert to data.table if not already
  if (!data.table::is.data.table(harmonized_data)) {
    harmonized_data <- data.table::as.data.table(harmonized_data)
  }
  
  # Estimate completion rates per year per country
  message("\nEstimating completion rates per year per country...")
  completion_rates <- estimate_completion_country_specific(
    harmonized_data = harmonized_data,
    country_codes = countries,
    years = years,
    level = levels,
    group_vars = group_vars,
    include_se = include_se
  )
  
  # Write output CSV
  if (!is.null(output_path)) {
    message("\nWriting completion rates to: ", output_path)
    data.table::fwrite(completion_rates, output_path)
  }
  
  # Report summary
  if (nrow(completion_rates) > 0) {
    unique_countries <- unique(completion_rates$country_code)
    unique_years <- unique(completion_rates$survey_year)
    message("\nGenerated ", nrow(completion_rates), " completion rate estimates")
    message("Countries: ", paste(unique_countries, collapse = ", "))
    message("Years: ", paste(sort(unique_years), collapse = ", "))
    message("Levels: ", paste(unique(completion_rates$level), collapse = ", "))
    
    # Show sample of output
    message("\nSample of output (first 5 rows):")
    print(completion_rates[1:min(5, nrow(completion_rates)), 
                           .(country_code, survey_year, level, rate)])
  } else {
    warning("No completion rates were generated")
  }
  
  return(completion_rates)
}

# Helper function for NULL coalescing
`%||%` <- function(x, y) if (is.null(x)) y else x