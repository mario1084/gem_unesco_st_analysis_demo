#' Write indicator outputs to CSV files
#'
#' Functions for writing indicator estimates to CSV files in the proper format.
#' Ensures consistent output structure across all indicator families.
#'
#' @name format_writers
NULL

#' Write household core indicators to CSV
#'
#' Writes household core indicator estimates to CSV files with proper formatting.
#' Creates separate files for each indicator or combined file based on parameters.
#'
#' @param indicator_data data.table with indicator estimates
#' @param output_dir Directory to write output files
#' @param indicator_id Optional indicator ID to filter data
#' @param combine Logical indicating whether to combine all indicators into one file
#' @param per_country_year Logical indicating whether to create separate files per country-year
#'
#' @return List of paths to created files
#' @export
write_household_indicators_csv <- function(indicator_data,
                                           output_dir,
                                           indicator_id = NULL,
                                           combine = TRUE,
                                           per_country_year = FALSE) {
  
  # Ensure output directory exists
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Filter by indicator_id if specified
  if (!is.null(indicator_id)) {
    indicator_data <- indicator_data[indicator_id %in% indicator_id]
  }
  
  if (nrow(indicator_data) == 0) {
    warning("No indicator data to write")
    return(character())
  }
  
  # Ensure required columns exist
  required_cols <- c("country_code", "survey_year", "indicator_id", "indicator_name", "rate")
  missing_cols <- setdiff(required_cols, names(indicator_data))
  if (length(missing_cols) > 0) {
    stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
  }
  
  # Add timestamp and metadata
  indicator_data[, output_timestamp := format(Sys.time(), "%Y-%m-%d %H:%M:%S")]
  indicator_data[, data_source := "gem_unesco_st_analysis_demo"]
  
  # Reorder columns for better readability
  base_cols <- c("country_code", "source_program", "survey_year", "wave_id",
                 "indicator_id", "indicator_name", "indicator_family", "level",
                 "rate", "numerator", "denominator", "n_eligible", "n_indicator")
  
  if ("se" %in% names(indicator_data)) {
    base_cols <- c(base_cols, "se", "ci_lower", "ci_upper")
  }
  
  base_cols <- c(base_cols, "country_specific_notes", "output_timestamp", "data_source")
  
  # Keep only columns that exist
  existing_cols <- intersect(base_cols, names(indicator_data))
  other_cols <- setdiff(names(indicator_data), existing_cols)
  all_cols <- c(existing_cols, other_cols)
  
  indicator_data <- indicator_data[, .SD, .SDcols = all_cols]
  
  # Write output based on parameters
  output_files <- list()
  
  if (combine && !per_country_year) {
    # Single combined file
    output_path <- file.path(output_dir, "household_core_indicators.csv")
    data.table::fwrite(indicator_data, output_path)
    output_files[["combined"]] <- output_path
    message("Written combined household indicators to: ", output_path)
    
  } else if (per_country_year) {
    # Separate files per country-year
    unique_combos <- unique(indicator_data[, .(country_code, survey_year)])
    
    for (i in 1:nrow(unique_combos)) {
      country <- unique_combos$country_code[i]
      year <- unique_combos$survey_year[i]
      
      country_year_data <- indicator_data[country_code == country & survey_year == year]
      
      if (nrow(country_year_data) > 0) {
        filename <- sprintf("household_indicators_%s_%s.csv", country, year)
        output_path <- file.path(output_dir, filename)
        data.table::fwrite(country_year_data, output_path)
        output_files[[paste(country, year, sep = "_")]] <- output_path
      }
    }
    message("Written ", length(output_files), " country-year household indicator files")
    
  } else {
    # Separate files per indicator
    unique_indicators <- unique(indicator_data$indicator_id)
    
    for (ind_id in unique_indicators) {
      ind_data <- indicator_data[indicator_id == ind_id]
      
      if (nrow(ind_data) > 0) {
        # Get indicator name for filename
        ind_name <- unique(ind_data$indicator_name)[1]
        safe_name <- gsub("[^a-zA-Z0-9]", "_", ind_name)
        filename <- sprintf("%s_%s.csv", ind_id, safe_name)
        output_path <- file.path(output_dir, filename)
        data.table::fwrite(ind_data, output_path)
        output_files[[ind_id]] <- output_path
      }
    }
    message("Written ", length(output_files), " indicator-specific files")
  }
  
  # Return summary
  summary_stats <- indicator_data[, .(
    n_estimates = .N,
    n_countries = uniqueN(country_code),
    n_years = uniqueN(survey_year),
    n_indicators = uniqueN(indicator_id)
  )]
  
  message("\nOutput summary:")
  message("  Total estimates: ", summary_stats$n_estimates)
  message("  Countries: ", summary_stats$n_countries)
  message("  Years: ", summary_stats$n_years)
  message("  Indicators: ", summary_stats$n_indicators)
  
  return(invisible(output_files))
}

#' Write platform-specific outputs
#'
#' Creates outputs formatted for specific platforms (WIDE, VIEW, SCOPE).
#'
#' @param indicator_data data.table with indicator estimates
#' @param output_dir Directory to write output files
#' @param platform Character vector of platforms: "WIDE", "VIEW", "SCOPE"
#'
#' @return List of paths to created files
#' @export
write_platform_outputs <- function(indicator_data,
                                   output_dir,
                                   platform = c("WIDE", "VIEW", "SCOPE")) {
  
  # Ensure output directory exists
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Load indicator registry to get platform mappings
  registry_path <- file.path(dirname(dirname(dirname(getwd()))), "config", "indicator_registry.csv")
  if (!file.exists(registry_path)) {
    warning("Indicator registry not found at: ", registry_path)
    return(list())
  }
  
  indicator_registry <- data.table::fread(registry_path)
  
  output_files <- list()
  
  for (plat in platform) {
    # Filter indicators for this platform
    platform_indicators <- indicator_registry[grepl(plat, platform, fixed = TRUE)]$indicator_id
    
    if (length(platform_indicators) == 0) {
      message("No indicators found for platform: ", plat)
      next
    }
    
    platform_data <- indicator_data[indicator_id %in% platform_indicators]
    
    if (nrow(platform_data) == 0) {
      message("No data for platform: ", plat)
      next
    }
    
    # Platform-specific formatting
    if (plat == "WIDE") {
      # WIDE format: country-year-indicator with inequality dimensions
      wide_data <- format_for_wide(platform_data)
      output_path <- file.path(output_dir, paste0("wide_format_", tolower(plat), ".csv"))
      data.table::fwrite(wide_data, output_path)
      
    } else if (plat == "VIEW") {
      # VIEW format: household + admin/reference context
      view_data <- format_for_view(platform_data)
      output_path <- file.path(output_dir, paste0("view_format_", tolower(plat), ".csv"))
      data.table::fwrite(view_data, output_path)
      
    } else if (plat == "SCOPE") {
      # SCOPE format: all layers integrated thematically
      scope_data <- format_for_scope(platform_data)
      output_path <- file.path(output_dir, paste0("scope_format_", tolower(plat), ".csv"))
      data.table::fwrite(scope_data, output_path)
    }
    
    output_files[[plat]] <- output_path
    message("Written ", plat, " format to: ", output_path)
  }
  
  return(invisible(output_files))
}

#' Format data for WIDE platform
#'
#' @param data Indicator data
#'
#' @return Formatted data for WIDE
format_for_wide <- function(data) {
  # WIDE expects country-year-indicator with inequality dimensions
  result <- copy(data)
  
  # Add WIDE-specific columns
  result[, wide_id := paste(country_code, survey_year, indicator_id, level, disaggregation_level, sep = "_")]
  result[, publication_status := ifelse(!is.na(rate), "published", "suppressed")]
  
  # Reorder columns
  disaggregation_vars <- setdiff(names(result), c("country_code", "source_program", "survey_year", "wave_id", "indicator_id", "indicator_name", "indicator_family", "level", "rate", "numerator", "denominator", "n_eligible", "n_indicator", "se", "ci_lower", "ci_upper", "country_specific_notes", "output_timestamp", "data_source", "wide_id", "publication_status", "disaggregation_level"))
  
  wide_cols <- c("wide_id", "country_code", "survey_year", "indicator_id", 
                 "indicator_name", "level", "disaggregation_level", disaggregation_vars, "rate", "se", "ci_lower", "ci_upper",
                 "publication_status", "country_specific_notes")
  
  existing_cols <- intersect(wide_cols, names(result))
  result <- result[, .SD, .SDcols = existing_cols]
  
  return(result)
}

#' Format data for VIEW platform
#'
#' @param data Indicator data
#'
#' @return Formatted data for VIEW
format_for_view <- function(data) {
  # VIEW expects household + admin/reference context
  result <- copy(data)
  
  # Add VIEW-specific columns
  result[, view_id := paste(country_code, survey_year, indicator_id, sep = "_")]
  result[, data_type := "household_survey"]
  
  # VIEW often includes admin context - this would need to be merged from admin data
  # For now, just mark that admin context is needed
  result[, admin_context_available := FALSE]
  result[, admin_context_note := "Admin context to be integrated separately"]
  
  # Reorder columns
  view_cols <- c("view_id", "country_code", "survey_year", "indicator_id",
                 "indicator_name", "data_type", "rate", "se", "ci_lower", "ci_upper",
                 "admin_context_available", "admin_context_note")
  
  existing_cols <- intersect(view_cols, names(result))
  result <- result[, .SD, .SDcols = existing_cols]
  
  return(result)
}

#' Format data for SCOPE platform
#'
#' @param data Indicator data
#'
#' @return Formatted data for SCOPE
format_for_scope <- function(data) {
  # SCOPE expects all layers integrated thematically
  result <- copy(data)
  
  # Add SCOPE-specific columns
  result[, scope_id := paste(country_code, survey_year, indicator_family, indicator_id, sep = "_")]
  result[, thematic_block := get_scope_thematic_block(indicator_family, indicator_id)]
  
  # SCOPE includes multiple data layers - mark source layer
  result[, source_layer := ifelse(indicator_family == "household_core", "household_survey", 
                                  ifelse(indicator_family == "learning_layer", "learning_assessment",
                                         ifelse(indicator_family == "admin_reference", "admin_data",
                                                ifelse(indicator_family == "finance_layer", "finance_data", "other"))))]
  
  # Reorder columns
  scope_cols <- c("scope_id", "country_code", "survey_year", "thematic_block",
                  "indicator_family", "indicator_id", "indicator_name", "source_layer",
                  "rate", "se", "ci_lower", "ci_upper")
  
  existing_cols <- intersect(scope_cols, names(result))
  result <- result[, .SD, .SDcols = existing_cols]
  
  return(result)
}

#' Get SCOPE thematic block for indicator
#'
#' @param indicator_family Indicator family
#' @param indicator_id Indicator ID
#'
#' @return Thematic block name
get_scope_thematic_block <- function(indicator_family, indicator_id) {
  # Map indicators to SCOPE thematic blocks
  blocks <- data.table::data.table(
    indicator_family = c("household_core", "household_core", "household_core", 
                         "household_core", "household_core", "household_core",
                         "learning_layer", "learning_layer", "learning_layer", "learning_layer",
                         "admin_reference", "admin_reference",
                         "finance_layer"),
    indicator_id = c("ATTEND_LVL", "OOS_LVL", "COMP_LVL", "LIT_RATE", "REP_RATE", "POSTSEC_REVIEW",
                     "LEARN_ERCE", "LEARN_PISA", "LEARN_PISAD", "LEARN_UIS",
                     "ADMIN_UIS", "POP_WPP",
                     "FIN_CRS"),
    thematic_block = c("access_participation", "access_participation", "completion_outcomes",
                       "learning_outcomes", "learning_outcomes", "tertiary_review",
                       "learning_assessments", "learning_assessments", "learning_assessments", "learning_assessments",
                       "system_characteristics", "demographic_context",
                       "finance_resources")
  )
  
  # Merge to get thematic block
  result <- data.table::data.table(indicator_family = indicator_family, indicator_id = indicator_id)
  result <- merge(result, blocks, by = c("indicator_family", "indicator_id"), all.x = TRUE)
  
  # Fill missing with "other"
  result[is.na(thematic_block), thematic_block := "other"]
  
  return(result$thematic_block)
}

#' Create output directory structure
#'
#' Creates standardized directory structure for indicator outputs.
#'
#' @param base_dir Base directory for outputs
#' @param create_subdirs Logical indicating whether to create subdirectories
#'
#' @return List of created directories
#' @export
create_output_structure <- function(base_dir, create_subdirs = TRUE) {
  
  dirs <- list(
    base = base_dir,
    household_core = file.path(base_dir, "household_core"),
    learning_layer = file.path(base_dir, "learning_layer"),
    admin_reference = file.path(base_dir, "admin_reference"),
    finance_layer = file.path(base_dir, "finance_layer"),
    platform_formats = file.path(base_dir, "platform_formats"),
    logs = file.path(base_dir, "logs"),
    metadata = file.path(base_dir, "metadata")
  )
  
  if (create_subdirs) {
    for (dir_path in dirs) {
      if (!dir.exists(dir_path)) {
        dir.create(dir_path, recursive = TRUE)
        message("Created directory: ", dir_path)
      }
    }
  }
  
  return(invisible(dirs))
}

#' Write metadata file
#'
#' Creates a metadata file describing the indicator outputs.
#'
#' @param indicator_data data.table with indicator estimates
#' @param output_dir Directory to write metadata file
#' @param run_id Optional run identifier
#'
#' @return Path to metadata file
#' @export
write_metadata <- function(indicator_data, output_dir, run_id = NULL) {
  
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }
  
  # Ensure we have a valid numeric column for summary
  if ("rate" %in% names(indicator_data) && "estimate" %in% names(indicator_data)) {
    indicator_data[, val_for_summary := fcoalesce(as.numeric(rate), as.numeric(estimate))]
  } else if ("rate" %in% names(indicator_data)) {
    indicator_data[, val_for_summary := as.numeric(rate)]
  } else if ("estimate" %in% names(indicator_data)) {
    indicator_data[, val_for_summary := as.numeric(estimate)]
  } else {
    indicator_data[, val_for_summary := NA_real_]
  }
  
  safe_min <- function(x) { if(all(is.na(x))) NA_real_ else min(x, na.rm = TRUE) }
  safe_max <- function(x) { if(all(is.na(x))) NA_real_ else max(x, na.rm = TRUE) }
  safe_mean <- function(x) { if(all(is.na(x))) NA_real_ else mean(x, na.rm = TRUE) }
  safe_sd <- function(x) { if(sum(!is.na(x)) < 2) NA_real_ else sd(x, na.rm = TRUE) }

  # Create metadata
  metadata <- list(
    run_info = list(
      run_id = run_id %||% format(Sys.time(), "%Y%m%d_%H%M%S"),
      timestamp = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
      system = Sys.info()["sysname"],
      r_version = R.version.string
    ),
    data_summary = list(
      n_estimates = nrow(indicator_data),
      n_countries = uniqueN(indicator_data$country_code),
      n_years = uniqueN(indicator_data$survey_year),
      n_indicators = uniqueN(indicator_data$indicator_id),
      date_range = paste(range(indicator_data$survey_year, na.rm = TRUE), collapse = "-"),
      countries = sort(unique(indicator_data$country_code))
    ),
    indicator_summary = indicator_data[, .(
      n_estimates = .N,
      min_val = safe_min(val_for_summary),
      max_val = safe_max(val_for_summary),
      mean_val = safe_mean(val_for_summary)
    ), by = .(indicator_id, indicator_name)],
    file_info = list(
      format = "CSV",
      encoding = "UTF-8",
      delimiter = ",",
      decimal_separator = "."
    )
  )
  
  # Write metadata as JSON
  metadata_path <- file.path(output_dir, "metadata.json")
  jsonlite::write_json(metadata, metadata_path, pretty = TRUE, auto_unbox = TRUE)
  
  # Also write as CSV summary
  summary_path <- file.path(output_dir, "summary_statistics.csv")
  summary_stats <- indicator_data[, .(
    n_estimates = .N,
    val_mean = safe_mean(val_for_summary),
    val_sd = safe_sd(val_for_summary),
    val_min = safe_min(val_for_summary),
    val_max = safe_max(val_for_summary),
    val_na = sum(is.na(val_for_summary))
  ), by = .(indicator_id, indicator_name)]
  
  data.table::fwrite(summary_stats, summary_path)
  
  message("Metadata written to: ", metadata_path)
  message("Summary statistics written to: ", summary_path)
  
  return(list(metadata = metadata_path, summary = summary_path))
}

# Helper function for NULL coalescing
`%||%` <- function(x, y) if (is.null(x)) y else x